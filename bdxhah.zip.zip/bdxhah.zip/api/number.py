from http.server import BaseHTTPRequestHandler
import json
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def number_lookup(phone):
    try:
        url = "https://ft-osint-api.duckdns.org/api/number"
        params = {"key": "draxion", "num": phone}
        resp = requests.get(url, params=params, timeout=25, verify=False)
        if resp.status_code == 200:
            data = resp.json()
            data.pop("by", None)
            data.pop("channel", None)
            return data
        return {"error": "No data found"}
    except Exception as e:
        return {"error": str(e)}

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        phone = self.path.split('=')[1] if '=' in self.path else None
        if not phone:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Missing phone parameter"}).encode())
            return
        
        result = number_lookup(phone)
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(result, indent=2).encode())