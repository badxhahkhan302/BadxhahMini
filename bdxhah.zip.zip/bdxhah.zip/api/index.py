import json
import requests
import urllib3
from datetime import datetime

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==================== CONFIGURATION ====================
FT_API_KEY = "draxion"
FT_BASE_URL = "https://ft-osint-api.duckdns.org"

# ==================== MAIN API FUNCTION ====================
def ft_call_api(endpoint: str, **params) -> dict:
    try:
        params["key"] = FT_API_KEY
        url = f"{FT_BASE_URL}{endpoint}"
        resp = requests.get(url, params=params, timeout=25, verify=False)
        
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, dict):
                # Remove unwanted fields
                for field in ["by", "channel", "credit", "api_valid_until", "days_remaining", "api_key_used"]:
                    data.pop(field, None)
            return data
        return {"error": f"API returned status {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}

# ==================== ALL FUNCTIONS ====================
def number_lookup(phone: str) -> dict:
    return ft_call_api("/api/number", num=phone)

def telegram_lookup(query: str) -> dict:
    clean_query = query.replace("@", "")
    apis = [
        {"url": "https://ft-osint-api.duckdns.org/api/tg", "params": {"key": "draxion", "info": clean_query}},
        {"url": "https://bronx-tg-king-bro.vercel.app/tg", "params": {"key": "BRONXop", "query": clean_query}},
        {"url": "https://impiyush.pro/tg.php", "params": {"apikey": "piyush07", "query": clean_query}},
    ]
    
    for api in apis:
        try:
            resp = requests.get(api["url"], params=api["params"], timeout=25, verify=False)
            if resp.status_code == 200:
                data = resp.json()
                if data and isinstance(data, dict):
                    for field in ["by", "channel", "credit", "api_valid_until", "days_remaining"]:
                        data.pop(field, None)
                    if data.get("message") != "No Data Found":
                        return data
        except:
            continue
    return {"error": "No data found"}

def aadhaar_lookup(aadhaar: str) -> dict:
    return ft_call_api("/api/aadhaar", num=aadhaar)

def email_lookup(email: str) -> dict:
    return ft_call_api("/api/emailtoinfo", email=email)

def name_lookup(name: str) -> dict:
    return ft_call_api("/api/name", name=name)

def instagram_lookup(username: str) -> dict:
    return ft_call_api("/api/insta", username=username)

def github_lookup(user: str) -> dict:
    return ft_call_api("/api/git", user=user)

def snapchat_lookup(username: str) -> dict:
    return ft_call_api("/api/snap", username=username)

def upi_lookup(upi: str) -> dict:
    return ft_call_api("/api/upi", upi=upi)

def ifsc_lookup(ifsc: str) -> dict:
    return ft_call_api("/api/ifsc", ifsc=ifsc)

def pan_to_gst(pan: str) -> dict:
    return ft_call_api("/api/pantogst", pan=pan)

def pincode_lookup(pincode: str) -> dict:
    return ft_call_api("/api/pincode", pincode=pincode)

def ip_lookup(ip: str) -> dict:
    return ft_call_api("/api/ip", ip=ip)

def vehicle_lookup(reg: str) -> dict:
    return ft_call_api("/api/vehicle", reg=reg)

def freefire_lookup(uid: str) -> dict:
    return ft_call_api("/api/ff", uid=uid)

def bgmi_lookup(uid: str) -> dict:
    return ft_call_api("/api/bgmi", uid=uid)

def paytm_lookup(phone: str) -> dict:
    return ft_call_api("/api/paytm", num=phone)

def basic_lookup(phone: str) -> dict:
    return ft_call_api("/api/basic", num=phone)

def imei_lookup(imei: str) -> dict:
    return ft_call_api("/api/imei", imei=imei)

def tgid_lookup(user_id: str) -> dict:
    return ft_call_api("/api/tgidinfo", id=user_id)

def pakistan_sim_lookup(num: str) -> dict:
    return ft_call_api("/api/pk", num=num)

def leak_lookup(term: str) -> dict:
    return ft_call_api("/api/leakinfo", term=term)

def advanced_lookup(query: str) -> dict:
    return ft_call_api("/api/advanced", query=query)

def aadhaar_family_lookup(aadhaar: str) -> dict:
    return ft_call_api("/api/adharfamily", num=aadhaar)

def sms_bomber(number: str, counter: int = 100) -> dict:
    return ft_call_api("/api/bomber", number=number, counter=counter)

ROUTES = {
    "number": number_lookup,
    "telegram": telegram_lookup,
    "aadhaar": aadhaar_lookup,
    "email": email_lookup,
    "name": name_lookup,
    "instagram": instagram_lookup,
    "github": github_lookup,
    "snapchat": snapchat_lookup,
    "upi": upi_lookup,
    "ifsc": ifsc_lookup,
    "pantogst": pan_to_gst,
    "pincode": pincode_lookup,
    "ip": ip_lookup,
    "vehicle": vehicle_lookup,
    "freefire": freefire_lookup,
    "bgmi": bgmi_lookup,
    "paytm": paytm_lookup,
    "basic": basic_lookup,
    "imei": imei_lookup,
    "tgid": tgid_lookup,
    "pakistan": pakistan_sim_lookup,
    "leak": leak_lookup,
    "advanced": advanced_lookup,
    "aadhaarfamily": aadhaar_family_lookup,
    "bomber": sms_bomber,
}

# ==================== VERCEL HANDLER ====================
def handler(request):
    """Main handler for Vercel"""
    path = request.path or "/"
    method = request.method or "GET"
    
    # Get query parameters
    params = {}
    if hasattr(request, 'query_params'):
        params = dict(request.query_params)
    else:
        # Parse manually
        if '?' in path:
            query_string = path.split('?')[1]
            for param in query_string.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    params[key] = value
            path = path.split('?')[0]
    
    # Remove leading slash
    path = path.strip('/')
    
    # Root path
    if not path or path == "api":
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "name": "Badxhah Khan OSINT Tools",
                "version": "1.0.0",
                "owner": "@BadxhahKhan",
                "endpoints": {
                    "number": "/number?phone=9876543210",
                    "telegram": "/telegram?query=@username",
                    "aadhaar": "/aadhaar?number=123456789012",
                    "email": "/email?email=user@example.com",
                    "name": "/name?name=John%20Doe",
                    "instagram": "/instagram?username=user",
                    "github": "/github?user=username",
                    "snapchat": "/snapchat?username=user",
                    "upi": "/upi?upi=user@okhdfcbank",
                    "ifsc": "/ifsc?code=SBIN0001234",
                    "pantogst": "/pantogst?pan=ABCDE1234F",
                    "pincode": "/pincode?code=110001",
                    "ip": "/ip?address=8.8.8.8",
                    "vehicle": "/vehicle?reg=DL01AB1234",
                    "freefire": "/freefire?uid=123456789",
                    "bgmi": "/bgmi?uid=123456789",
                    "paytm": "/paytm?phone=9876543210",
                    "basic": "/basic?phone=9876543210",
                    "imei": "/imei?imei=123456789012345",
                    "tgid": "/tgid?id=123456789",
                    "pakistan": "/pakistan?num=03331234567",
                    "leak": "/leak?term=email@example.com",
                    "advanced": "/advanced?query=john%20doe",
                    "aadhaarfamily": "/aadhaarfamily?number=123456789012",
                    "bomber": "/bomber?number=9876543210&counter=100"
                }
            })
        }
    
    # Check if route exists
    if path in ROUTES:
        # Get parameter
        param_map = {
            "number": "phone", "telegram": "query", "aadhaar": "number",
            "email": "email", "name": "name", "instagram": "username",
            "github": "user", "snapchat": "username", "upi": "upi",
            "ifsc": "code", "pantogst": "pan", "pincode": "code",
            "ip": "address", "vehicle": "reg", "freefire": "uid",
            "bgmi": "uid", "paytm": "phone", "basic": "phone",
            "imei": "imei", "tgid": "id", "pakistan": "num",
            "leak": "term", "advanced": "query", "aadhaarfamily": "number",
            "bomber": "number"
        }
        
        param_name = param_map.get(path)
        
        if path == "bomber":
            number = params.get("number", params.get("phone"))
            counter = int(params.get("counter", 100))
            if number:
                result = ROUTES[path](number, counter)
            else:
                result = {"error": "Missing number parameter"}
        elif param_name and param_name in params:
            result = ROUTES[path](params[param_name])
        else:
            result = {"error": f"Missing parameter: {param_name}", "example": f"/{path}?{param_name}=value"}
        
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(result, indent=2)
        }
    else:
        return {
            "statusCode": 404,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "error": "Endpoint not found",
                "available": list(ROUTES.keys())
            }, indent=2)
        }

# ==================== For Local Testing ====================
if __name__ == "__main__":
    from http.server import HTTPServer, BaseHTTPRequestHandler
    
    class LocalHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            class Request:
                path = self.path
                method = "GET"
                query_params = {}
                if '?' in self.path:
                    qs = self.path.split('?')[1]
                    for p in qs.split('&'):
                        if '=' in p:
                            k, v = p.split('=', 1)
                            Request.query_params[k] = v
            
            response = handler(Request())
            self.send_response(response["statusCode"])
            for key, value in response["headers"].items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(response["body"].encode())
    
    print("Server running on http://localhost:8080")
    HTTPServer(("", 8080), LocalHandler).serve_forever()